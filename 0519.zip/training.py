
# coding: utf-8

# In[1]:


import torch
import torch.nn as nn
import torch.nn.init as nn_init
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from DataLoader import data_loader
import torchvision.transforms as transforms
from SegNet import SegNet


# In[17]:


# Hyprt Parameter
num_image = 100  # Size of dataset
index = np.arange(num_image).tolist()
np.random.shuffle(index) # Shuffle data

root = './Cityscape_modified/' # Root path
mode = 'train' # train, test, valid
output_size = (450, 900)  # (height, width)

Transform_data = transforms.Compose([transforms.Resize(output_size),
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
                                    ])
Transform_lbl  = transforms.Compose([transforms.Resize(output_size),
                                     transforms.ToTensor(),
                                    ])



# # Training

# In[21]:


class_num = [0, 7, 11, 26, 24]
net = SegNet(class_num = len(class_num), img_size = (450, 900))
net = net.cuda()

optimizer = torch.optim.Adam(net.parameters(), lr = 0.0001)
criteria = nn.CrossEntropyLoss()


# In[22]:


loss_list = []
train_loader = data_loader(index, root, mode, Transform_data, Transform_lbl, class_num)
for counter, elements in enumerate(train_loader):
    train_img = elements[0].cuda()
    train_lbl = elements[1].long().cuda()
    output = net(train_img)
    print(type(output))
    print(type(train_lbl))
    loss = criteria(output, train_lbl)
    loss_list.append(loss)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    
    


# In[23]:


x = np.arange(num_image)
loss_list
plt.figure()
plt.plot(x, loss_list)
plt.show()

